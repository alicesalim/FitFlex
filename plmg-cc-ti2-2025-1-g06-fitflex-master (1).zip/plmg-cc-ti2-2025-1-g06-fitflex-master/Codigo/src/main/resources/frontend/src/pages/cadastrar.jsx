import Signup from "../components/signup/signup";

const Cadastrar = () => {
    return (
      <div className="p-6 text-center">
        <div className="loginuser">
        <Signup />
        </div>
      </div>
    );
  };
  
  export default Cadastrar;