import Card  from "../components/ia/ia";

const Analisar = () => {
    return (
      <div className="p-6 text-center">
          <Card />
      </div>
    );
  };
  
  export default Analisar;