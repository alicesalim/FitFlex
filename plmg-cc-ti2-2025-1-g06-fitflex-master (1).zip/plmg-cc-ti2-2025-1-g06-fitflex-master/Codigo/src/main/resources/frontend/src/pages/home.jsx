import Intro from "../components/intro/intro";


const Home = () => {
    return(
        <div>
            <Intro />
        </div>
    );

};
export default Home;