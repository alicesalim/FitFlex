const Plans = () => {
    return (
      <div className="p-6 text-center">
        <h1 className="text-3xl font-bold">Sobre Nós</h1>
        <p className="mt-4 text-lg text-gray-600">
          Página Plans
        </p>
      </div>
    );
  };
  
  export default Plans;
  